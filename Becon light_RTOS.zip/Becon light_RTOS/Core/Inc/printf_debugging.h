/*
 * printf_debugging.h
 *
 *  Created on: Dec 10, 2024
 *      Author: nishant
 */

#ifndef INC_PRINTF_DEBUGGING_H_
#define INC_PRINTF_DEBUGGING_H_
#include <stdio.h>

// Write a specified number of bytes from a memory buffer to a file descriptor.
// This function is primarily used for debugging purposes, similar to printf.
int _write(int file, char *ptr, int len);

//function to print the message in hexadecimal from.
void printMessage( const unsigned char *, const int);

void printMessage2( const unsigned char *message, const int length);
#endif /* INC_PRINTF_DEBUGGING_H_ */
