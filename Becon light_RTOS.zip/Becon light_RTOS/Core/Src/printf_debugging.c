/*
 * printf_debugging.c
 *

 */
#include <stdio.h>
#include <ctype.h>
#include "main.h"




int _write(int file, char *ptr, int len)
{

  int DataIdx;

  for (DataIdx = 0; DataIdx < len; DataIdx++)
  {
	  ITM_SendChar(*ptr++);
  }
  return len;
}

void printMessage( const unsigned char *message, const int length)
{
//	printf("{");
    for( int i = 0; i < length; i+=2 ){
        printf( "0x%02x, 0x%02x", message[i], message[i+1] );
        if (i < length-2)
                	printf(", ");
    }
//    printf("},");
//    printf( "\n\r" );
}//print message ends

void printMessage2( const unsigned char *message, const int length)
{
    for( int i = 0; i < length; i+=2 ){
        printf( "%02x%02x", message[i], message[i+1] );
    }
    printf( "\n" );
}//print message ends


