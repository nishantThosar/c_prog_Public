/*
 * RTOS_Tasks.h
 *
 *  Created on: Jun 26, 2025
 *      Author: nishant
 */

#ifndef INC_RTOS_TASKS_H_
#define INC_RTOS_TASKS_H_

#include "cmsis_os.h"
#include "main.h"   // For LED_Pin and huart2

extern osThreadId_t LED_ONHandle;
extern osThreadId_t LED_OFFHandle;
extern osThreadId_t morse_code_blinHandle;
extern osThreadId_t Nishant_morseHandle;

extern osSemaphoreId_t LED_onHandle;
extern osSemaphoreId_t LED_offHandle;
extern osSemaphoreId_t morseHandle;
extern osSemaphoreId_t Nishant_MorseHandle;

extern const osThreadAttr_t LED_ON_attributes;
extern const osThreadAttr_t LED_OFF_attributes;
extern const osThreadAttr_t morse_code_blin_attributes;
extern const osThreadAttr_t Nishant_morse_attributes;

extern UART_HandleTypeDef huart2;

void MX_RTOS_Tasks_Init(void);  // Call this from main
void LED_ON_TASK(void *argument);
void TURN_OFF(void *argument);
void morse_blink_start(void *argument);
void Morse_nishant_blink(void *argument);


#endif /* INC_RTOS_TASKS_H_ */
