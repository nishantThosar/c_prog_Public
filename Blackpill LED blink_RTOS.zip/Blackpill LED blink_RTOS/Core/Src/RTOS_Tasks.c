/*
 * RTOS_Tasks.c
 *
 *  Created on: Jun 26, 2025
 *      Author: nishant
 */

#include "RTOS_Tasks.h"

/* Definitions for LED_ON */
osThreadId_t LED_ONHandle;
const osThreadAttr_t LED_ON_attributes = {
  .name = "LED_ON",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for LED_OFF */
osThreadId_t LED_OFFHandle;
const osThreadAttr_t LED_OFF_attributes = {
  .name = "LED_OFF",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for morse_code_blin */
osThreadId_t morse_code_blinHandle;
const osThreadAttr_t morse_code_blin_attributes = {
  .name = "morse_code_blin",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for Nishant_morse */
osThreadId_t Nishant_morseHandle;
const osThreadAttr_t Nishant_morse_attributes = {
  .name = "Nishant_morse",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for LED_on */
osSemaphoreId_t LED_onHandle;
const osSemaphoreAttr_t LED_on_attributes = {
  .name = "LED_on"
};
/* Definitions for LED_off */
osSemaphoreId_t LED_offHandle;
const osSemaphoreAttr_t LED_off_attributes = {
  .name = "LED_off"
};
/* Definitions for morse */
osSemaphoreId_t morseHandle;
const osSemaphoreAttr_t morse_attributes = {
  .name = "morse"
};
/* Definitions for Nishant_Morse */
osSemaphoreId_t Nishant_MorseHandle;
const osSemaphoreAttr_t Nishant_Morse_attributes = {
  .name = "Nishant_Morse"
};

void MX_RTOS_Tasks_Init(void)
{
  /* Create the semaphores(s) */
  /* creation of LED_on */
  LED_onHandle = osSemaphoreNew(1, 1, &LED_on_attributes);

  /* creation of LED_off */
  LED_offHandle = osSemaphoreNew(1, 0, &LED_off_attributes);

  /* creation of morse */
  morseHandle = osSemaphoreNew(1, 0, &morse_attributes);

  /* creation of Nishant_Morse */
  Nishant_MorseHandle = osSemaphoreNew(1, 0, &Nishant_Morse_attributes);

  /* Create the thread(s) */
  /* creation of LED_ON */
  LED_ONHandle = osThreadNew(LED_ON_TASK, NULL, &LED_ON_attributes);

  /* creation of LED_OFF */
  LED_OFFHandle = osThreadNew(TURN_OFF, NULL, &LED_OFF_attributes);

  /* creation of morse_code_blin */
  morse_code_blinHandle = osThreadNew(morse_blink_start, NULL, &morse_code_blin_attributes);

  /* creation of Nishant_morse */
  Nishant_morseHandle = osThreadNew(Morse_nishant_blink, NULL, &Nishant_morse_attributes);

}

  void LED_ON_TASK(void *argument)
  {
    /* USER CODE BEGIN 5 */

    /* Infinite loop */
    for(;;)
    {
  	osSemaphoreAcquire(LED_onHandle, osWaitForever);
      HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET); // ON
      osDelay(100);
      HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);   // OFF
      osDelay(100);

      HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET); // ON again
      osDelay(100);
      HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);   // OFF
      osDelay(700); // pause before repeating
      HAL_UART_Transmit(&huart2, (uint8_t*)"\n\rExit LED On", strlen("\n\rExit LED On"), 1000);
      osSemaphoreRelease(LED_offHandle);
    }
    /* USER CODE END 5 */
  }

  void TURN_OFF(void *argument)
  {
    /* USER CODE BEGIN TURN_OFF */

    /* Infinite loop */
    for(;;)
    {
  	osSemaphoreAcquire(LED_offHandle, osWaitForever);
      HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET); // ON (active low)
      osDelay(200); // short flash

      HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);   // OFF
      osDelay(800); // long off
      HAL_UART_Transmit(&huart2, (uint8_t*)"\n\rExit LED OFF", strlen("\n\rExit LED On"), 1000);
      osSemaphoreRelease(morseHandle);
    }
    /* USER CODE END TURN_OFF */
  }


  void morse_blink_start(void *argument)
  {
    /* USER CODE BEGIN morse_blink_start */
  	// DOT = 200ms ON, DASH = 600ms ON, 200ms off between blinks
  	uint16_t dot = 200, dash = 600;

    /* Infinite loop */
    for(;;)
    {
  		osSemaphoreAcquire(morseHandle, osWaitForever);
  	    // S: ...
  	    for (int i = 0; i < 3; i++) {
  	        HAL_GPIO_WritePin(GPIOC, LED_Pin, GPIO_PIN_RESET); osDelay(dot);
  	        HAL_GPIO_WritePin(GPIOC, LED_Pin, GPIO_PIN_SET); osDelay(200);
  	    }

  	    // O: ---
  	    for (int i = 0; i < 3; i++) {
  	        HAL_GPIO_WritePin(GPIOC, LED_Pin, GPIO_PIN_RESET); osDelay(dash);
  	        HAL_GPIO_WritePin(GPIOC, LED_Pin, GPIO_PIN_SET); osDelay(200);
  	    }

  	    // S: ...
  	    for (int i = 0; i < 3; i++) {
  	        HAL_GPIO_WritePin(GPIOC, LED_Pin, GPIO_PIN_RESET); osDelay(dot);
  	        HAL_GPIO_WritePin(GPIOC, LED_Pin, GPIO_PIN_SET); osDelay(200);
  	    }

  	    osDelay(2000); // Pause before next SOS
  	    HAL_UART_Transmit(&huart2, (uint8_t*)"\n\rExit SOS morse", strlen("\n\rExit SOS morse"), 1000);
  	    osSemaphoreRelease(Nishant_MorseHandle);
    }
    /* USER CODE END morse_blink_start */
  }

  void Morse_nishant_blink(void *argument)
  {
    /* USER CODE BEGIN Morse_nishant_blink */
  #define DOT_TIME   200
  #define DASH_TIME  600
  #define SYMBOL_GAP 200
  #define LETTER_GAP 600

  void blinkDot() {
      HAL_GPIO_WritePin(GPIOC, LED_Pin, GPIO_PIN_RESET); // ON
      osDelay(DOT_TIME);
      HAL_GPIO_WritePin(GPIOC, LED_Pin, GPIO_PIN_SET); // OFF
      osDelay(SYMBOL_GAP);
  }

  void blinkDash() {
      HAL_GPIO_WritePin(GPIOC, LED_Pin, GPIO_PIN_RESET); // ON
      osDelay(DASH_TIME);
      HAL_GPIO_WritePin(GPIOC, LED_Pin, GPIO_PIN_SET); // OFF
      osDelay(SYMBOL_GAP);
  }
    /* Infinite loop */
    for(;;)
    {
  		osSemaphoreAcquire(Nishant_MorseHandle, osWaitForever);
  	  // N (− •)
  	          blinkDash();
  	          blinkDot();
  	          osDelay(LETTER_GAP);

  	          // I (• •)
  	          blinkDot();
  	          blinkDot();
  	          osDelay(LETTER_GAP);

  	          // S (• • •)
  	          blinkDot();
  	          blinkDot();
  	          blinkDot();
  	          osDelay(LETTER_GAP);

  	          // H (• • • •)
  	          blinkDot();
  	          blinkDot();
  	          blinkDot();
  	          blinkDot();
  	          osDelay(LETTER_GAP);

  	          // A (• −)
  	          blinkDot();
  	          blinkDash();
  	          osDelay(LETTER_GAP);

  	          // N (− •)
  	          blinkDash();
  	          blinkDot();
  	          osDelay(LETTER_GAP);

  	          // T (−)
  	          blinkDash();
  	          osDelay(1400); // Word gap (7 units) before looping
  	          HAL_UART_Transmit(&huart2, (uint8_t*)"\n\rExit NISHANT morse", strlen("\n\rExit NISHANT morse"), 1000);
  	          osSemaphoreRelease(LED_onHandle);
    }
    /* USER CODE END Morse_nishant_blink */
  }
