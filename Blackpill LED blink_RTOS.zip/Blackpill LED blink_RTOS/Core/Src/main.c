/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart2;

/* Definitions for LED_ON
osThreadId_t LED_ONHandle;
const osThreadAttr_t LED_ON_attributes = {
  .name = "LED_ON",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
 Definitions for LED_OFF
osThreadId_t LED_OFFHandle;
const osThreadAttr_t LED_OFF_attributes = {
  .name = "LED_OFF",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
 Definitions for morse_code_blin
osThreadId_t morse_code_blinHandle;
const osThreadAttr_t morse_code_blin_attributes = {
  .name = "morse_code_blin",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
 Definitions for Nishant_morse
osThreadId_t Nishant_morseHandle;
const osThreadAttr_t Nishant_morse_attributes = {
  .name = "Nishant_morse",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
 Definitions for LED_on
osSemaphoreId_t LED_onHandle;
const osSemaphoreAttr_t LED_on_attributes = {
  .name = "LED_on"
};
 Definitions for LED_off
osSemaphoreId_t LED_offHandle;
const osSemaphoreAttr_t LED_off_attributes = {
  .name = "LED_off"
};
 Definitions for morse
osSemaphoreId_t morseHandle;
const osSemaphoreAttr_t morse_attributes = {
  .name = "morse"
};
 Definitions for Nishant_Morse
osSemaphoreId_t Nishant_MorseHandle;
const osSemaphoreAttr_t Nishant_Morse_attributes = {
  .name = "Nishant_Morse"
};*/
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
void LED_ON_TASK(void *argument);
void TURN_OFF(void *argument);
void morse_blink_start(void *argument);
void Morse_nishant_blink(void *argument);

/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/*---------------------------- UART Transmitting buffer -------------------------------*/
uint8_t *transmitt_buffer[] = {
    (uint8_t *)" \nLED ON\n",
    (uint8_t *)" \nLED OFF\n",
	(uint8_t *)" \nWaiting for Semaphore in LED ON\n",
	(uint8_t *)" \nWaiting for Semaphore in LED OFF\n",
	(uint8_t *)" \nExit Task ON\n\r",
	(uint8_t *)" \nExit Task OFF\n\r",
};
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Init scheduler */
  osKernelInitialize();

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  MX_RTOS_Tasks_Init();
  /* USER CODE END RTOS_MUTEX */

/*   Create the semaphores(s)
   creation of LED_on
  LED_onHandle = osSemaphoreNew(1, 1, &LED_on_attributes);

   creation of LED_off
  LED_offHandle = osSemaphoreNew(1, 0, &LED_off_attributes);

   creation of morse
  morseHandle = osSemaphoreNew(1, 0, &morse_attributes);

   creation of Nishant_Morse
  Nishant_MorseHandle = osSemaphoreNew(1, 0, &Nishant_Morse_attributes);*/

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

/*   Create the thread(s)
   creation of LED_ON
  LED_ONHandle = osThreadNew(LED_ON_TASK, NULL, &LED_ON_attributes);

   creation of LED_OFF
  LED_OFFHandle = osThreadNew(TURN_OFF, NULL, &LED_OFF_attributes);

   creation of morse_code_blin
  morse_code_blinHandle = osThreadNew(morse_blink_start, NULL, &morse_code_blin_attributes);

   creation of Nishant_morse
  Nishant_morseHandle = osThreadNew(Morse_nishant_blink, NULL, &Nishant_morse_attributes);*/

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 75;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : LED_Pin */
  GPIO_InitStruct.Pin = LED_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED_GPIO_Port, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/* USER CODE BEGIN Header_LED_ON_TASK */
/**
  * @brief  Function implementing the LED_ON thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_LED_ON_TASK */
/*void LED_ON_TASK(void *argument)
{
   USER CODE BEGIN 5

   Infinite loop
  for(;;)
  {
	osSemaphoreAcquire(LED_onHandle, osWaitForever);
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET); // ON
    osDelay(100);
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);   // OFF
    osDelay(100);

    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET); // ON again
    osDelay(100);
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);   // OFF
    osDelay(700); // pause before repeating
    HAL_UART_Transmit(&huart2, (uint8_t*)"\n\rExit LED On", strlen("\n\rExit LED On"), 1000);
    osSemaphoreRelease(LED_offHandle);
  }
   USER CODE END 5
}*/

/* USER CODE BEGIN Header_TURN_OFF */
/**
* @brief Function implementing the LED_OFF thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_TURN_OFF */
/*void TURN_OFF(void *argument)
{
   USER CODE BEGIN TURN_OFF

   Infinite loop
  for(;;)
  {
	osSemaphoreAcquire(LED_offHandle, osWaitForever);
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET); // ON (active low)
    osDelay(200); // short flash

    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);   // OFF
    osDelay(800); // long off
    HAL_UART_Transmit(&huart2, (uint8_t*)"\n\rExit LED OFF", strlen("\n\rExit LED On"), 1000);
    osSemaphoreRelease(morseHandle);
  }
   USER CODE END TURN_OFF
}*/

/* USER CODE BEGIN Header_morse_blink_start */
/**
* @brief Function implementing the morse_code_blin thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_morse_blink_start */
/*void morse_blink_start(void *argument)
{
   USER CODE BEGIN morse_blink_start
	// DOT = 200ms ON, DASH = 600ms ON, 200ms off between blinks
	uint16_t dot = 200, dash = 600;

   Infinite loop
  for(;;)
  {
		osSemaphoreAcquire(morseHandle, osWaitForever);
	    // S: ...
	    for (int i = 0; i < 3; i++) {
	        HAL_GPIO_WritePin(GPIOC, LED_Pin, GPIO_PIN_RESET); osDelay(dot);
	        HAL_GPIO_WritePin(GPIOC, LED_Pin, GPIO_PIN_SET); osDelay(200);
	    }

	    // O: ---
	    for (int i = 0; i < 3; i++) {
	        HAL_GPIO_WritePin(GPIOC, LED_Pin, GPIO_PIN_RESET); osDelay(dash);
	        HAL_GPIO_WritePin(GPIOC, LED_Pin, GPIO_PIN_SET); osDelay(200);
	    }

	    // S: ...
	    for (int i = 0; i < 3; i++) {
	        HAL_GPIO_WritePin(GPIOC, LED_Pin, GPIO_PIN_RESET); osDelay(dot);
	        HAL_GPIO_WritePin(GPIOC, LED_Pin, GPIO_PIN_SET); osDelay(200);
	    }

	    osDelay(2000); // Pause before next SOS
	    HAL_UART_Transmit(&huart2, (uint8_t*)"\n\rExit SOS morse", strlen("\n\rExit SOS morse"), 1000);
	    osSemaphoreRelease(Nishant_MorseHandle);
  }
   USER CODE END morse_blink_start
}*/

/* USER CODE BEGIN Header_Morse_nishant_blink */
/**
* @brief Function implementing the Nishant_morse thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Morse_nishant_blink */
/*void Morse_nishant_blink(void *argument)
{
   USER CODE BEGIN Morse_nishant_blink
#define DOT_TIME   200
#define DASH_TIME  600
#define SYMBOL_GAP 200
#define LETTER_GAP 600

void blinkDot() {
    HAL_GPIO_WritePin(GPIOC, LED_Pin, GPIO_PIN_RESET); // ON
    osDelay(DOT_TIME);
    HAL_GPIO_WritePin(GPIOC, LED_Pin, GPIO_PIN_SET); // OFF
    osDelay(SYMBOL_GAP);
}

void blinkDash() {
    HAL_GPIO_WritePin(GPIOC, LED_Pin, GPIO_PIN_RESET); // ON
    osDelay(DASH_TIME);
    HAL_GPIO_WritePin(GPIOC, LED_Pin, GPIO_PIN_SET); // OFF
    osDelay(SYMBOL_GAP);
}
   Infinite loop
  for(;;)
  {
		osSemaphoreAcquire(Nishant_MorseHandle, osWaitForever);
	  // N (− •)
	          blinkDash();
	          blinkDot();
	          osDelay(LETTER_GAP);

	          // I (• •)
	          blinkDot();
	          blinkDot();
	          osDelay(LETTER_GAP);

	          // S (• • •)
	          blinkDot();
	          blinkDot();
	          blinkDot();
	          osDelay(LETTER_GAP);

	          // H (• • • •)
	          blinkDot();
	          blinkDot();
	          blinkDot();
	          blinkDot();
	          osDelay(LETTER_GAP);

	          // A (• −)
	          blinkDot();
	          blinkDash();
	          osDelay(LETTER_GAP);

	          // N (− •)
	          blinkDash();
	          blinkDot();
	          osDelay(LETTER_GAP);

	          // T (−)
	          blinkDash();
	          osDelay(1400); // Word gap (7 units) before looping
	          HAL_UART_Transmit(&huart2, (uint8_t*)"\n\rExit NISHANT morse", strlen("\n\rExit NISHANT morse"), 1000);
	          osSemaphoreRelease(LED_onHandle);
  }
   USER CODE END Morse_nishant_blink
}*/

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM1 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM1) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
