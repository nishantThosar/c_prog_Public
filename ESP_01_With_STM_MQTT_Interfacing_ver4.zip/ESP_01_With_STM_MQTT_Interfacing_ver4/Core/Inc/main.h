/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "main.h"
#include "string.h"
#include "printf_debugging.h"
#include "ESP_Communication.h"
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */
extern uint8_t mqtt_ready;
extern uint8_t rx_data;
extern volatile uint8_t rx_complete ;
extern volatile uint8_t rx_line_ready;

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */
/*void send_mqtt_message(const char *topic, const char *message, uint8_t retain);
void send_wifi_credentials(const char *ssid, const char *password);
void send_mqtt_credentials(const char *broker_ip, const char *username, const char *password, int port, uint8_t auth_required);*/
/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define green_Pin GPIO_PIN_12
#define green_GPIO_Port GPIOD
#define orange_Pin GPIO_PIN_13
#define orange_GPIO_Port GPIOD
#define red_Pin GPIO_PIN_14
#define red_GPIO_Port GPIOD
#define blue_Pin GPIO_PIN_15
#define blue_GPIO_Port GPIOD

/* USER CODE BEGIN Private defines */

#define Auth_REQUIRED  1				//AUTHORIZATRION IS REQUIRED FOR MQTT.
#define ANONYMOUS_MODE 0				//ANONYMOUS MODE FOR MQTT.
#define RETAIN 1						//FOR SETTING RETAINED MESSAGE IN MQTT.
#define LIVE   0						//FOR SETTING UNRETAINED MESSAGE IN MQTT (NORMAL MESSAGE).

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
