/**
 * @file printf_debugging.h
 * @brief Header file for debugging utilities using printf-like functionality.
 *
 * This file provides the function prototypes for writing debug messages 
 * and printing data in a hexadecimal format. These functions are designed 
 * to assist in debugging by allowing data inspection during runtime.
 *
 */

#ifndef INC_PRINTF_DEBUGGING_H_
#define INC_PRINTF_DEBUGGING_H_
#include <stdio.h>
/**
 * @brief Writes a specified number of bytes from a memory buffer to a file descriptor.
 *
 * This function is a low-level utility designed to mimic the behavior of printf
 * by writing the specified number of bytes from the buffer to the given file descriptor.
 * It is primarily used for debugging purposes.
 *
 * @param file The file descriptor to which the data will be written.
 * @param ptr Pointer to the memory buffer containing the data to be written.
 * @param len Number of bytes to write from the buffer.
 * @return The number of bytes written, or -1 if an error occurs.
 */
int _write(int file, char *ptr, int len);

/**
 * @brief Prints a message in hexadecimal format.
 *
 * This function takes a byte array and its length, and prints the data in
 * hexadecimal format to provide a clear view of its content for debugging purposes.
 *
 * @param message Pointer to the array of bytes to be printed.
 * @param length Length of the byte array.
 * @note Ensure that the `message` pointer is valid and that `length` does not
 * exceed the buffer size to avoid undefined behavior.
 */
void printMessage(const unsigned char *message, const int length);

#endif /* INC_PRINTF_DEBUGGING_H_ */
