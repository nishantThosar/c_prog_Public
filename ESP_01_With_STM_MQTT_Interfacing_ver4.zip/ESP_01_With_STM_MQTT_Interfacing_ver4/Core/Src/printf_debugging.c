/**
 * @file printf_debugging.c
 * @brief This file provides functions for debugging using printf-style output via ITM (Instrumentation Trace Macrocell).
 * 
 * The functions in this file allow formatted output for debugging purposes. They include implementations 
 * for sending characters via ITM and printing formatted messages for data inspection.
 * 
 */

#include <stdio.h>    ///< Standard I/O functions for formatted output
#include <ctype.h>    ///< Character handling functions
#include "main.h"     ///< Main application header

/**
 * @brief Low-level implementation for `_write`, used by printf for ITM output.
 * 
 * This function overrides the `_write` system call, redirecting printf output to the ITM_SendChar function.
 * It sends characters one by one through the Instrumentation Trace Macrocell (ITM) interface for debugging.
 * 
 * @param file File descriptor (not used in this implementation).
 * @param ptr Pointer to the character buffer to be written.
 * @param len Number of characters to write.
 * 
 * @return Number of characters successfully written.
 */
int _write(int file, char *ptr, int len)
{
    int DataIdx;

    for (DataIdx = 0; DataIdx < len; DataIdx++)
    {
        ITM_SendChar(*ptr++); ///< Send each character via ITM
    }
    return len;
}

/**
 * @brief Prints a formatted message as a hexadecimal array.
 * 
 * This function takes an array of unsigned characters and prints it in a formatted hexadecimal style. 
 * It pairs the array elements into groups of two and outputs them in the following format:
 * 
 * Example for a `message` of `{0x12, 0x34, 0x56, 0x78}`:
 * ```
 * {0x12, 0x34, 0x56, 0x78},
 * ```
 * 
 * @param message Pointer to the array of unsigned characters to be printed.
 * @param length Length of the message array.
 * 
 * @note The function assumes that the array length is an even number for proper pairing.
 */
void printMessage(const unsigned char *message, const int length)
{
    printf("{");
    for (int i = 0; i < length; i += 2)
    {
        printf("0X%02X, 0X%02X", message[i], message[i + 1]); ///< Print two elements at a time in hexadecimal format
        if (i < length )
            printf(", ");
    }
    printf("},"); ///< End the array format
    printf("\n\r");
}
