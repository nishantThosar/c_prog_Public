#ifndef ESP_COMMUNICATION_H
#define ESP_COMMUNICATION_H

#include "stm32f4xx_hal.h"  // Required for UART_HandleTypeDef
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif



// ------------------------------------------
// ESP State Machine Enumeration
// ------------------------------------------
typedef enum {
    ESP_STATE_IDLE = 0,
    ESP_STATE_WIFI_CONNECTING,
    ESP_STATE_WIFI_CONNECTED,
    ESP_STATE_MQTT_CONNECTING,
    ESP_STATE_MQTT_CONNECTED,
    ESP_STATE_ERROR
} ESP_State;

// ------------------------------------------
// Public API Functions
// ------------------------------------------

/**
 * @brief Send WiFi SSID and password to ESP.
 * @param huart UART handle for communication.
 * @param ssid WiFi SSID string.
 * @param password WiFi password string.
 */
void send_wifi_credentials(UART_HandleTypeDef *huart, const char *ssid, const char *password);

/**
 * @brief Send MQTT broker info to ESP.
 * @param huart UART handle.
 * @param broker_ip MQTT broker IP string.
 * @param username MQTT username (optional).
 * @param password MQTT password (optional).
 * @param port MQTT port (e.g., 1883).
 * @param auth_required Set to 1 if username/password is needed.
 */
void send_mqtt_credentials(UART_HandleTypeDef *huart, const char *broker_ip,
                           const char *username, const char *password,
                           int port, uint8_t auth_required);

/**
 * @brief Publish a message to a given MQTT topic.
 * @param huart UART handle.
 * @param topic MQTT topic string.
 * @param message Message to send.
 * @param retain Retain flag (0 or 1).
 */
void send_mqtt_message(UART_HandleTypeDef *huart, const char *topic,
                       const char *message, uint8_t retain);

// ------------------------------------------
// State Management
// ------------------------------------------

/**
 * @brief Set internal state of ESP module.
 * @param state Enum value from ESP_State
 */
void esp_set_state(ESP_State state);

/**
 * @brief Get current state of ESP module.
 * @return ESP_State enum value.
 */
ESP_State esp_get_state(void);

// ------------------------------------------
// Debug / Monitoring
// ------------------------------------------

/**
 * @brief Get number of successful transmissions.
 * @return Count of successful UART transmissions.
 */
uint32_t get_tx_success_count(void);

/**
 * @brief Get number of failed transmissions (after retries).
 * @return Count of UART transmission failures.
 */
uint32_t get_tx_failure_count(void);

void esp_publish_json_message(UART_HandleTypeDef *huart, const char *topic, uint8_t retain, int pair_count, ...);

void send_subscribe_topic(UART_HandleTypeDef *huart,const char *subscribe_topic);

void process_received_line(char* line);

void reset_mqtt(UART_HandleTypeDef *huart);

void start_uart4_rx_dma(void);

#ifdef __cplusplus
}
#endif

#endif // ESP_COMMUNICATION_H
