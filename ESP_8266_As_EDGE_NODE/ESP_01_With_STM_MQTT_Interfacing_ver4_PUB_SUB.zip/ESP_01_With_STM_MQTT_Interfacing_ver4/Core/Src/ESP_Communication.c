/*
 * ESP_Communication.c
 *
 * Created on: Jul 17, 2025
 * Enhanced: Jul 22, 2025
 */

#include <string.h>
#include <stdio.h>
#include "main.h"
#include "ESP_Communication.h"
#include <stdarg.h>  // for variadic args


// -----------------------------
// Configuration & Buffers
// -----------------------------
#define RX_BUFFER_SIZE 256
#define MAX_RETRIES     3
#define DEBUG_UART      huart2  // Modify if needed
/*-------------------- MQTT Receiving Buffer ---------------------------------*/
uint8_t UART1_RxBuffer[APP_BUFFER_SIZE];
uint8_t AppBuffer[APP_BUFFER_SIZE];
uint16_t WriteIndex = 0;   // next free position in ring buffer
/*-------------------------- END ---------------------------------------------*/
/*uint8_t rx_data;
static uint8_t rx_buffer[RX_BUFFER_SIZE];
static uint8_t rx_index = 0;*/
static ESP_State esp_state = ESP_STATE_IDLE;

// -----------------------------
// Statistics
// -----------------------------
static uint32_t tx_success_count = 0;
static uint32_t tx_failure_count = 0;

extern UART_HandleTypeDef huart4;

void start_uart4_rx_dma(void)
{
    // Start DMA reception into RxBuffer
    HAL_UARTEx_ReceiveToIdle_DMA(&huart4, UART1_RxBuffer, APP_BUFFER_SIZE);

    // Disable half-transfer interrupts (not useful for most UART cases)
    __HAL_DMA_DISABLE_IT(huart4.hdmarx, DMA_IT_HT);
}

// -----------------------------
// Safe UART Transmission
// -----------------------------
static HAL_StatusTypeDef uart_send_with_retry(UART_HandleTypeDef *huart, const char *data)
{
    HAL_StatusTypeDef status = HAL_ERROR;
    for (int attempt = 0; attempt < MAX_RETRIES; attempt++) {
        status = HAL_UART_Transmit(huart, (uint8_t *)data,(uint8_t) strlen(data), HAL_MAX_DELAY);
        if (status == HAL_OK) {
            tx_success_count++;
            return HAL_OK;
        }
    }
    tx_failure_count++;
    return status;
}

// -----------------------------
// State Setter & Getter
// -----------------------------
void esp_set_state(ESP_State state) {
    esp_state = state;
}

ESP_State esp_get_state(void) {
    return esp_state;
}

// -----------------------------
// API: Send WiFi Credentials
// -----------------------------
void send_wifi_credentials(UART_HandleTypeDef *huart, const char *ssid, const char *password)
{
    if (!huart || !ssid || !password || strlen(ssid) > 32 || strlen(password) > 64) {
        esp_set_state(ESP_STATE_ERROR);
        return;
    }

    char cmd[128];
    int len = snprintf(cmd, sizeof(cmd), "wifi=%s;pass=%s;\n", ssid, password);
    if (len < 0 || len >= sizeof(cmd)) {
        esp_set_state(ESP_STATE_ERROR);
        return;
    }

    esp_set_state(ESP_STATE_WIFI_CONNECTING);
    if (uart_send_with_retry(huart, cmd) != HAL_OK) {
        esp_set_state(ESP_STATE_ERROR);
    } else {
        esp_set_state(ESP_STATE_WIFI_CONNECTED);
    }
}
// -----------------------------
// API: Send MQTT Credentials
// -----------------------------
void send_mqtt_credentials(UART_HandleTypeDef *huart, const char *broker_ip, const char *username, const char *password, int port, uint8_t auth_required)
{
    if (!huart || !broker_ip || port < 1 || port > 65535) {
        esp_set_state(ESP_STATE_ERROR);
        return;
    }
    char cmd[160];
    int len = 0;
    if (auth_required) {
        if (!username || !password) {
            esp_set_state(ESP_STATE_ERROR);
            return;
        }
        len = snprintf(cmd, sizeof(cmd),
            "auth=1;broker=%s;mqtt_user=%s;mqtt_pass=%s;port=%d;\n",
            broker_ip, username, password, port);
    } else {
        len = snprintf(cmd, sizeof(cmd),
            "auth=0;broker=%s;port=%d;\n", broker_ip, port);
    }
    if (len < 0 || len >= sizeof(cmd)) {
        esp_set_state(ESP_STATE_ERROR);
        return;
    }
    esp_set_state(ESP_STATE_MQTT_CONNECTING);
    if (uart_send_with_retry(huart, cmd) != HAL_OK) {
        esp_set_state(ESP_STATE_ERROR);
    } else {
        esp_set_state(ESP_STATE_MQTT_CONNECTED);
    }
}

// -----------------------------
// API: Send MQTT Message
// -----------------------------
void send_mqtt_message(UART_HandleTypeDef *huart, const char *topic, const char *message, uint8_t retain)
{
    if (!huart || !topic || !message || retain > 1) {
        esp_set_state(ESP_STATE_ERROR);
        return;
    }
    char cmd[160];
    int len = snprintf(cmd, sizeof(cmd), "topic=%s;msg=%s;retain=%d;\n", topic, message, retain);
    if (len < 0 || len >= sizeof(cmd)) {
        esp_set_state(ESP_STATE_ERROR);
        return;
    }
    if (uart_send_with_retry(huart, cmd) != HAL_OK) {
        esp_set_state(ESP_STATE_ERROR);
    }
}
/*------------------------------------------ Restart ESP ------------------------------------------*/
void reset_mqtt(UART_HandleTypeDef *huart)
{
    if (!huart)
    {
        esp_set_state(ESP_STATE_ERROR);
        return;
    }

    const char *cmd = "reset_esp;\n";   // command format matching ESP parser

    if (uart_send_with_retry(huart, cmd) != HAL_OK)
    {
        esp_set_state(ESP_STATE_ERROR);
        printf("\n\r Error in resetting the ESP01\n\r");
    }
    printf("\n\rResetting the ESP01\n\r");
    HAL_Delay(1000);
}
// -----------------------------
// Receive Handler
// -----------------------------
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
    if (huart->Instance == UART4)
    {
        // Copy ONLY the new data into the ring buffer
        for (int i=0; i < Size; i++)
        {

            AppBuffer[WriteIndex++] = UART1_RxBuffer[i];
            if (WriteIndex >= APP_BUFFER_SIZE)   // wrap if end reached
            {
            	WriteIndex = 0;
            }
        }
//        memset(UART1_RxBuffer, '0',Size);
    	WriteIndex = 0;
        // Example: check if last char was newline -> full message ready
        if (AppBuffer[(WriteIndex - 1 + APP_BUFFER_SIZE) % APP_BUFFER_SIZE] == '\n')
        {
            // Extract the message from buffer
            // (you could write a parser here instead of raw printf)
            printf("\n\r Full Msg: ");

            // Walk backwards to find start of message
            int idx = (WriteIndex - 1 + APP_BUFFER_SIZE) % APP_BUFFER_SIZE;
            while (idx >= 0 && AppBuffer[idx] != '\n')
                idx = (idx - 1 + APP_BUFFER_SIZE) % APP_BUFFER_SIZE;

            // Print message in order
            int start = (idx + 1) % APP_BUFFER_SIZE;
            while (start != WriteIndex)
            {
                printf("%c",AppBuffer[start]);
                start = (start + 1) % APP_BUFFER_SIZE;
            }
            printf("\r\n");
        }
    }
}

/**
 * @brief Example: Publishing JSON formatted data
 */
void esp_publish_json_message(UART_HandleTypeDef *huart, const char *topic, uint8_t retain, int pair_count, ...)
{
    if (!huart || !topic || pair_count <= 0 || pair_count > 10) return;

    char json_buffer[160] = {0};
    strcat(json_buffer, "{");

    va_list args;
    va_start(args, pair_count);

    for (int i = 0; i < pair_count; i++)
    {
        const char *key = va_arg(args, const char*);
        const char *value = va_arg(args, const char*);

        if (!key || !value) continue;

        // Append key-value pair safely
        char pair[64];
        snprintf(pair, sizeof(pair), "\"%s\":\"%s\"", key, value);

        strcat(json_buffer, pair);

        if (i < pair_count - 1) {
            strcat(json_buffer, ",");
        }
    }

    strcat(json_buffer, "}");
    va_end(args);

    // Publish the JSON string over MQTT
    send_mqtt_message(huart, topic, json_buffer, retain);
}

/*
 * @brief: This function is for sendin the topic to subscribe to the ESP.
 * */
void send_subscribe_topic(UART_HandleTypeDef *huart,const char *subscribe_topic)
{
  char cmd[128];
  snprintf(cmd, sizeof(cmd), "sub=%s;\n", subscribe_topic);
  HAL_UART_Transmit(huart, (uint8_t*)cmd, (uint8_t)strlen(cmd), HAL_MAX_DELAY);
  printf("\n\rSubscribe command sent-> Topic= \" %s\" \n\r", subscribe_topic);
}
void process_received_line(char* line)
{
  if (strncmp(line, "submsg=", 7) == 0) {
    printf("\n[MQTT Received]: %s\n", line + 7);
  } else {
    printf("[ESP]: %s\n", line);
  }
}
// -----------------------------
// Debug Monitoring APIs
// -----------------------------
uint32_t get_tx_success_count(void) {
    return tx_success_count;
}

uint32_t get_tx_failure_count(void) {
    return tx_failure_count;
}


