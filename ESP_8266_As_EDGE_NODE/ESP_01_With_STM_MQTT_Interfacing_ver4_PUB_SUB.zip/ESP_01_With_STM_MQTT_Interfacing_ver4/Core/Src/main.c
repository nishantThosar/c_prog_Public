/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart4;
UART_HandleTypeDef huart2;
DMA_HandleTypeDef hdma_uart4_rx;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_UART4_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
/*-------------------- MQTT Receiving Buffer ---------------------------------
uint8_t UART1_RxBuffer[APP_BUFFER_SIZE];
uint8_t AppBuffer[APP_BUFFER_SIZE];
uint16_t WriteIndex = 0;   // next free position in ring buffer
-------------------------- END ---------------------------------------------*/

/*void start_uart4_rx_dma(void)
{
    // Start DMA reception into RxBuffer
    HAL_UARTEx_ReceiveToIdle_DMA(&huart4, UART1_RxBuffer, APP_BUFFER_SIZE);

    // Disable half-transfer interrupts (not useful for most UART cases)
    __HAL_DMA_DISABLE_IT(huart4.hdmarx, DMA_IT_HT);
}*/
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
/*--------------------- WIFI Credentials -------------------------------------*/
const char *wifi_ssid 			= "ESP32_NAT_Router";
const char *wifi_password 		= "";
/*--------------------- MQTT Credentials -------------------------------------*/
const char *mqtt_broker_ip  	= "192.168.4.31";
const char *mqtt_username   	= "mqtt_user";
const char *mqtt_password   	= "mqtt_pass";
int         mqtt_port			= 1883;
/*--------------------- MQTT Topic & Message ----------------------------------*/
const char *mqtt_topic 			= "esp01/send";
const char *mqtt_topic_json		= "esp01/send/json";
const char *mqtt_sub_topic		= "esp01/rec";
const char *mqtt_retain_message = "Hello from DISCOVERY! 1";
const char *mqtt_live_message   = "Hello from DISCOVERY! 32";
/*-------------------------- END ---------------------------------------------*/


  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  printf("\n\rThis code is in combination of \"esp01_stm32_mqtt_ver2.0 \" for ESP-01. \n");
  printf("\n\r This code gives credentials of WIFI and MQTT to the ESP and the Message which has to be sent over the topic.\n The main file for ESP-01 is ESP_Communication.c there you can find the definitions of the functions for communication stack.\n\r");
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART2_UART_Init();
  MX_UART4_Init();
  /* USER CODE BEGIN 2 */
  reset_mqtt(&huart4);

  send_wifi_credentials(&huart4, wifi_ssid, wifi_password); //send the password and SSID of server on which MQTT broker is connected.
  HAL_Delay(50);
  printf("\n\rSent WIFI credentials \" SSID: %s, Password: %s \" \n\r", wifi_ssid, wifi_password);
  send_subscribe_topic(&huart4, mqtt_sub_topic);
  send_mqtt_credentials(&huart4, mqtt_broker_ip ,mqtt_username ,mqtt_password , mqtt_port, ANONYMOUS_MODE); //Send the MQTT credentials to ESP.
  // Wait until ESP connects to MQTT
  HAL_Delay(3000);
//  HAL_UARTEx_ReceiveToIdle_DMA(&huart4, UART1_RxBuffer,UART_RX_BUFFER_SIZE);
  // Start first DMA reception

  bzero(UART1_RxBuffer,UART_RX_BUFFER_SIZE);
  bzero(AppBuffer,APP_BUFFER_SIZE);


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
      //Restart DMA reception from index 0.
      start_uart4_rx_dma();

send_mqtt_message(&huart4, mqtt_topic_json, mqtt_live_message, 0);
HAL_Delay(1000);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */


  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief UART4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART4_Init(void)
{

  /* USER CODE BEGIN UART4_Init 0 */

  /* USER CODE END UART4_Init 0 */

  /* USER CODE BEGIN UART4_Init 1 */

  /* USER CODE END UART4_Init 1 */
  huart4.Instance = UART4;
  huart4.Init.BaudRate = 115200;
  huart4.Init.WordLength = UART_WORDLENGTH_8B;
  huart4.Init.StopBits = UART_STOPBITS_1;
  huart4.Init.Parity = UART_PARITY_NONE;
  huart4.Init.Mode = UART_MODE_TX_RX;
  huart4.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart4.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART4_Init 2 */

  /* USER CODE END UART4_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Stream2_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream2_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream2_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, green_Pin|orange_Pin|red_Pin|blue_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : green_Pin orange_Pin red_Pin blue_Pin */
  GPIO_InitStruct.Pin = green_Pin|orange_Pin|red_Pin|blue_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
/*void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
    if (huart->Instance == UART4)
    {
        // Copy ONLY the new data into the ring buffer
        for (int i=0; i < Size; i++)
        {

            AppBuffer[WriteIndex++] = UART1_RxBuffer[i];
            if (WriteIndex >= APP_BUFFER_SIZE)   // wrap if end reached
            {
            	WriteIndex = 0;
            }
        }
//        memset(UART1_RxBuffer, '0',Size);
    	WriteIndex = 0;
        // Example: check if last char was newline -> full message ready
        if (AppBuffer[(WriteIndex - 1 + APP_BUFFER_SIZE) % APP_BUFFER_SIZE] == '\n')
        {
            // Extract the message from buffer
            // (you could write a parser here instead of raw printf)
            printf("Full Msg: ");

            // Walk backwards to find start of message
            int idx = (WriteIndex - 1 + APP_BUFFER_SIZE) % APP_BUFFER_SIZE;
            while (idx >= 0 && AppBuffer[idx] != '\n')
                idx = (idx - 1 + APP_BUFFER_SIZE) % APP_BUFFER_SIZE;

            // Print message in order
            int start = (idx + 1) % APP_BUFFER_SIZE;
            while (start != WriteIndex)
            {
                printf("%c",AppBuffer[start]);
                start = (start + 1) % APP_BUFFER_SIZE;
            }
            printf("\r\n");
        }

//        // Restart reception
//        HAL_UARTEx_ReceiveToIdle_DMA(&huart4, UART1_RxBuffer, UART_RX_BUFFER_SIZE);

        //Restart DMA reception from index 0.

    }
}*/
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
